document.addEventListener('DOMContentLoaded', function () {
    alert("JavaScript is working! Testing form prevention...");
    const form = document.getElementById("contactForm");
    const messageDiv = document.querySelector(".form-message");



    // ===== STAR RATING FUNCTIONALITY =====
    const stars = document.querySelectorAll('.star'); // assumes stars have class "star"
    let starRating = 0;

    stars.forEach((star, index) => {
        star.addEventListener('click', () => {
            starRating = index + 1; // rating from 1 to 5
            updateStars();
        });

        // Optional: hover effect
        star.addEventListener('mouseover', () => {
            highlightStars(index + 1);
        });
        star.addEventListener('mouseout', () => {
            highlightStars(starRating);
        });
    });

    function updateStars() {
        stars.forEach((star, index) => {
            if (index < starRating) {
                star.classList.add('selected'); // selected star style
            } else {
                star.classList.remove('selected');
            }
        });
    }

    function highlightStars(count) {
        stars.forEach((star, index) => {
            if (index < count) {
                star.classList.add('hovered');
            } else {
                star.classList.remove('hovered');

            }
        });
    }

    // ===== EXISTING FORM SUBMISSION LOGIC =====
    form.addEventListener('submit', function (e) {
        e.preventDefault(); // Prevent default form submission

        // Get form field values
        const name = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const service = document.getElementById('service').value;
        const message = document.getElementById('message').value.trim();
        const review = document.getElementById('review') ? document.getElementById('review').value.trim() : '';

        // Clear previous error messages
        const errors = form.querySelectorAll('.error');
        errors.forEach(err => err.remove());

        let valid = true;

        // Validate Name
        if (name === '') {
            showError('name', 'Please enter your name.');
            valid = false;
        }

        // Validate Email
        if (email === '') {
            showError('email', 'Please enter your email.');
            valid = false;
        } else if (!validateEmail(email)) {
            showError('email', 'Please enter a valid email.');
            valid = false;
        }

        // Validate Service
        if (!service) {
            showError('service', 'Please select a service.');
            valid = false;
        }

        // Validate Message
        if (message === '') {
            showError('message', 'Please enter your message.');
            valid = false;
        }

        // Validate Review
        if (review === '') {
            showError('review', 'Please enter your review.');
            valid = false;
        }

        // Validate Star Rating
        if (starRating === 0) {
            const starContainer = document.querySelector('.star-container'); // container of stars
            const error = document.createElement('div');
            error.className = 'error';
            error.style.color = 'red';
            error.style.marginTop = '5px';
            error.textContent = 'Please select a star rating.';
            starContainer.appendChild(error);
            valid = false;
        }

        if (!valid) return;

        // Prepare data to send
        const formData = {
            name: name,
            email: email,
            service: service,
            message: message,
            review: review,
            rating: starRating // include star rating
        };

        // AJAX submission
        fetch('submit_form.php', { // Replace with your server-side script
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        })
            .then(response => response.json())
            .then(data => {
                alert(data.message || 'Form submitted successfully!');
                form.reset();
                starRating = 0;
                updateStars(); // reset stars
            })
            .catch(error => {
                alert('An error occurred. Please try again.');
                console.error(error);
            });
    });

    // ===== EXISTING HELPER FUNCTIONS =====
    function showError(fieldId, message) {
        const field = document.getElementById(fieldId);
        const error = document.createElement('div');
        error.className = 'error';
        error.style.color = 'red';
        error.style.marginTop = '5px';
        error.textContent = message;
        field.parentNode.insertBefore(error, field.nextSibling);
    }

    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

}
